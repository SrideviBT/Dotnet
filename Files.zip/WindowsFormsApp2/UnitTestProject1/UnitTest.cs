﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http.Results;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using StoreApp.Controllers;
using StoreApp.Models;

namespace StoreApp.Tests
{
    [TestClass]
    public class TestSimpleProductController
    {
        [TestMethod]
        public void GetAll_ShouldReturnAllEmployees()
        {
            var testProducts = GetTestProducts();
            var controller = new Form1(button1_Click);

            var result = controller.button1_Click() as List<Employee>;
            Assert.AreEqual(testProducts.Count, result.Count);
        }

       
    }
}