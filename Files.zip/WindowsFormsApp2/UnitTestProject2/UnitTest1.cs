﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Security.Principal;
using WindowsFormsApp2;

namespace UnitTestProject2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Employee obj = new WindowsFormsApp2.Employee();
            obj.id="123456";
            Assert.AreEqual(obj.id, obj.name);

        }
    }
}
